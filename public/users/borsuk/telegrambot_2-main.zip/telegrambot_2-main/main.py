from pydoc_data.topics import topics
import telebot 
bot = telebot.TeleBot('5264347755:AAH8jlQyGDcPau-sv6a3XzcDLRulKMzjH4o') 

news = {
    'Sport': {
        'footbal': {},
        'hockey': {},
        'tennis': {},
    },
    'Politics': {},
    'Animal World': {},
    'games': {},
}
peopleList = {}

def step_add_topics(topics): 
    topics = telebot.types.ReplyKeyboardMarkup(resize_keyboard=True) 
    for i in news: 
        topics.add(telebot.types.KeyboardButton(i))
    topicsChoice = bot.send_message(topics.chat.id, f'<b>Выбери интересные для тебя темы.</b>', parse_mode='html',  reply_markup=topics)
    bot.register_next_step_handler(topicsChoice, step_topics_list)

def step_topics_list(topics):
    if topics.chat.id in peopleList:
        if (topics.text in peopleList[topics.chat.id])  is False:
            peopleList[topics.chat.id].append(topics.text)
    else:
        peopleList[topics.chat.id] = [topics.text]    
    preferences = peopleList[topics.chat.id]
    bot.send_message(topics.chat.id, f'<b>Список ваших придпочтений: {preferences}.</b>', parse_mode='html')
    nextOrBack = telebot.types.ReplyKeyboardMarkup(resize_keyboard=True) 
    nextOrBack.add(telebot.types.KeyboardButton('Получить новости'))
    nextOrBack.add(telebot.types.KeyboardButton('Добавить придпочтение'))
    next = bot.send_message(topics.chat.id, f'<b>Хотите добавить?.</b>', parse_mode='html',  reply_markup=nextOrBack)
    if next.text == 'Добавить придпочтение':
        bot.register_next_step_handler(nextOrBack, step_add_topics)

@bot.message_handler(content_types=['text'])
def get_user_text(message): 
    bot.send_message(message.chat.id, f'<b>Привет, {message.from_user.first_name}! Здесь ты можешь найти интересующие тебя новости.</b>', parse_mode='html')
    topics = telebot.types.ReplyKeyboardMarkup(resize_keyboard=True) 
    for i in news: 
        topics.add(telebot.types.KeyboardButton(i))
    topicsChoice = bot.send_message(message.chat.id, f'<b>Выбери интересные для тебя темы.</b>', parse_mode='html',  reply_markup=topics)
    bot.register_next_step_handler(topicsChoice, step_topics_list)

bot.polling(non_stop=True, skip_pending=True) # Запускаем бот
