import json

car = {
    'brands': {
        'Subaru': {
            'legacy b4': {
                'bl': {
                    'Замена ремня генератора': {
                        'about': {
                            'text':'Прежде всего, перед заменой ремня генератора нужно точно определить, что указанный элемент нуждается в замене. Начнем с того, что по времени и пробегу лучше менять такой ремень каждые 5 лет или 80-100 тыс. пробега независимо от состояния ремня. Еще в процессе эксплуатации ремень нужно периодически проверять каждые 20-30 тыс. км. На начальном этапе проверок следует обратить внимание на признаки износа ремня. Например, на необходимость внеплановой проверки укажет характерный свист во время работы ДВС, который локализуется в области привода навесных агрегатов. Если свистит только периодически и во влажную погоду, это не является поводом для сильного беспокойства.',
                            'image': [
                                './image/subaru/legacy-b4/bl/1.jpg',
                                './image/subaru/legacy-b4/bl/2.jpg'
                            ]
                        },
                        'youtube': ['https://www.youtube.com/watch?v=s42r5WlTTmY', 'https://youtu.be/d9THI0eefn4'],
                        'service': [
                            {'adress': 'Subaru Service Nsk. Сибиряков-Гвардейцев, 47 к9, Новосибирск', 'url': 'https://2gis.ru/novosibirsk/geo/141266769701112'}
                        ],
                        'market': [
                            {'market':'FARPOST', 'url': 'https://www.farpost.ru/zapchasti/+/%D1%80%D0%B5%D0%BC%D0%B5%D0%BD%D1%8C/model/subaru+legacy+b4/body/bl5/'}
                        ]
                    },
                },
                'bh': {
                    'Замена переднего ступичного подшипника': {
                        'about': {
                            'text':'Это отчетливый хруст, стук или скрежет в области колеса. Вы услышите его и в автомобиле и снаружи, когда машина проезжает мимо. Еще одним признаком неисправности ступичного подшипника является вибрация, которая передается и на руль и на всю машину.',
                            'image': [
                                './image/subaru/legacy-b4/bh/1.jpg',
                                './image/subaru/legacy-b4/bh/2.jpg',
                                './image/subaru/legacy-b4/bh/3.jpg',
                                './image/subaru/legacy-b4/bh/4.jpg',
                                './image/subaru/legacy-b4/bh/5.jpg',
                                './image/subaru/legacy-b4/bh/6.jpg',
                                './image/subaru/legacy-b4/bh/7.jpg',
                            ]
                        },
                        'youtube': ['https://youtu.be/k3RmCEK2GSU'],
                        'service': [
                            {'adress': 'Subaru Service Nsk. Сибиряков-Гвардейцев, 47 к9, Новосибирск', 'url': 'https://2gis.ru/novosibirsk/geo/141266769701112'}
                        ],
                        'market': [
                            {'market':'FARPOST', 'url': 'https://www.farpost.ru/zapchasti/+/%D1%80%D0%B5%D0%BC%D0%B5%D0%BD%D1%8C/model/subaru+legacy+b4/body/bl5/'}
                        ]
                    }
                }
                
            },
        
        },
        'Mercedes Benz': {
            'C-class С-180': {
                'W202': {
                    'Замена ручника': {
                        'about': {
                            'text':'Собственноручная замена троса ручника, на первый взгляд, может показаться простой слесарной задачей.',
                            'image': [
                            './image/mercedes-benz/c-class-c-180/W202/1.jpg',
                            './image/mercedes-benz/c-class-c-180/W202/2.jpg',
                            './image/mercedes-benz/c-class-c-180/W202/3.jpg',
                            './image/mercedes-benz/c-class-c-180/W202/4.jpg',
                            './image/mercedes-benz/c-class-c-180/W202/5.jpg',
                            './image/mercedes-benz/c-class-c-180/W202/6.jpg',
                            './image/mercedes-benz/c-class-c-180/W202/7.jpg',
                            './image/mercedes-benz/c-class-c-180/W202/8.jpg',
                            './image/mercedes-benz/c-class-c-180/W202/9.jpg',
                            './image/mercedes-benz/c-class-c-180/W202/10.jpg',
                            ]
                        },
                        'youtube': ['https://youtu.be/EXf1p3EVPoQ'],
                        'service': [
                            {'adress': 'Новосибирск — 2ГИС', 'url': 'https://2gis.ru/novosibirsk/search/%D0%A1%D0%B5%D1%80%D0%B2%D0%B8%D1%81%20mercedes%20(mercedes-benz)/attributeId/70000201006751051/firm/141265771044263/82.96652%2C55.0535?m=82.906639%2C54.97903%2F13.71'}
                        ],
                        'market': [
                            {'market':'ДРОМ', 'url': 'https://baza.drom.ru/sell_spare_parts/+/%F2%F0%EE%F1%E8%EA+%F0%F3%F7%ED%EE%E3%EE+%F2%EE%F0%EC%EE%E7%E0/model/mercedes-benz+c-class/body/w202/'}
                        ]
                    },
                },
                
            },
        
        },
        'Тayota': {
            'chaser': {
                '100': {
                    'Замена свечей зажигания': {
                        'about': {
                            'text':'Симптомы неисправности свечей зажигания: потеря мощности, что приводит к повышенному расходу топлива; провалы в мощности при резком нажатии на газ; неравномерная работа двигателя, двигатель глохнет; троение и вибрация двигателя, особенно на холостых оборотах',
                            'image': [
                                './image/tayota/chaser/100/1.jpg',
                                './image/tayota/chaser/100/2.jpg',
                                './image/tayota/chaser/100/3.jpg',
                                './image/tayota/chaser/100/4.jpg',
                                './image/tayota/chaser/100/5.jpg',
                                './image/tayota/chaser/100/6.jpg',
                            ]
                        },
                        'youtube': ['https://youtu.be/6ncWMtrsXKs'],
                        'service': [
                            {'adress': 'Япония, автоцентр, Королёва, 40 к2, Новосибирск — 2ГИС', 'url': 'https://2gis.ru/novosibirsk/search/%D0%B0%D0%B2%D1%82%D0%BE%D1%81%D0%B5%D1%80%D0%B2%D0%B8%D1%81/firm/141265769609942?m=82.978447%2C55.055493%2F14.79'}
                        ],
                        'market': [
                            {'market':'АВТОМАНИЯ', 'url': 'https://automania-shop.ru/catalog/svechi_zazhiganiya/toyota/chaser/'}
                        ]
                    },
                },
                
            },
        
        },

    }
}
with open('data.json', 'w') as outfile:
    json.dump(car, outfile)
