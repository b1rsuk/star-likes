from ast import arg
from email import message
from operator import mod
import telebot # Для работы с телеграмом. pip install pyTelegramBotAPI
import json # Для работы с json 
bot = telebot.TeleBot('5341416589:AAGbqCq6_J-WgKOcLnsVfFESc5ICUEvMfhI') # Секретный токен
import time

with open('./data.json', 'r', encoding='utf-8') as f: # Открываем список 
    car = json.load(f) # Парсим список и заганяем в пременую


grade = []

for brand in car['brands']: # Проходимся по брендам
    for model in car['brands'][brand]: # Проходимся по моделям
        for body in car['brands'][brand][model]: #  Проходимся по кузовам
            for problem in car['brands'][brand][model][body]: # Проходимся по проблемам
                grade.append({"brand": brand, "model": model, "body": body, "problem": problem, "like": 0, "dislike": 0}) # Добавляем в массив обьект 

            

def step_grade(fist, args):
    
    for i in grade: # Проходимся по обьектам grade
        if i['brand'] == args['brand'] and i['model'] == args['model'] and i['body'] == args['body'] and i['problem'] == args['problem']: # Если текущие значение совпадает со всеми выбраными варинтами
            if fist.text == '👍': # Если нажата кнопка лайк
                i['like'] += 1 # Добавляем значению like 1
            elif fist.text == '👎': # 
                i['dislike'] += 1 # Добавляем значению dislike 1
            else: # Если не один вариант не выбран 
                return # Завершаем функцию
            article_like = i['like'] # Запишем кол лайков. Нужно для того что бы вывести в строке
            article_dislike = i['dislike'] # Запишем кол дислайков. Нужно для того что бы вывести в строке
            bot.send_message(fist.chat.id, f'<b>Оценка статьи: 👍 - {article_like} 👎 - {article_dislike}</b>', parse_mode='html') # Отправляем сообщение
    start = telebot.types.ReplyKeyboardMarkup().add(telebot.types.KeyboardButton('/start')) # Создаем внопку вызывающею комманду /start
    bot.send_message(fist.chat.id, '<b>Чтобы продолжить напишите: /start</b>', parse_mode='html', reply_markup=start) # Отправляем сообщение

def step_result(problem, args):
    if problem.text == 'Меню': # Если выбрана кнопка меню 
        start = telebot.types.ReplyKeyboardMarkup().add(telebot.types.KeyboardButton('/start')) # Создаем внопку вызывающею комманду /start
        bot.send_message(problem.chat.id, '<b>Чтобы продолжить напишите: /start</b>', parse_mode='html', reply_markup=start) # Отправляем сообщение
        return # Завершаем функцию
    if (problem.text in car['brands'][args['brand']][args['model']][ args['body'] ]) is False: # Если ответ от пользователя это не одна из кнопок то выходим 
        return # Завершаем функцию

    bot.send_message(problem.chat.id, car['brands'][ args['brand'] ][ args['model'] ][ args['body'] ][ problem.text ]['about']['text'], parse_mode='html') # Отправляем описание выбраной проблемы
    for i in car['brands'][ args['brand'] ][ args['model'] ][ args['body'] ][ problem.text ]['about']['image']: # Проходимся по директориям картинок
        time.sleep(1) # Задержка на 1 секунду
        bot.send_photo(problem.chat.id, open(i, 'rb')) # Отправляем картинку

    for i in car['brands'][ args['brand'] ][ args['model'] ][ args['body'] ][ problem.text ]['youtube']: # Проходимся по списку видео
        time.sleep(1) # Задержка на 1 секунду
        bot.send_message(problem.chat.id, i, parse_mode='html') # Отпраляем ссылку на видео

    market = telebot.types.InlineKeyboardMarkup() # Обьявляем меню магазинов
    for i in car['brands'][ args['brand'] ][ args['model'] ][ args['body'] ][ problem.text ]['market']: # Проходимся по списку магазнов
        market.add(telebot.types.InlineKeyboardButton(i['market'], i['url'])) # Добавляем ссылку на магазин в кнопку
    bot.send_message(problem.chat.id, '<b>Здесь вы можете купить деталь:</b>', parse_mode='html', reply_markup=market) # Отправляем сообщение и кнопки

    services = telebot.types.InlineKeyboardMarkup() # Обьявляем меню ремон сервисов
    for i in car['brands'][ args['brand'] ][ args['model'] ][ args['body'] ][ problem.text ]['service']: # Проходимся по ремон сервисам
        services.add(telebot.types.InlineKeyboardButton(i['adress'], i['url'])) # Добавляем сервис в меню кнопок
    bot.send_message(problem.chat.id, '<b>Здесь вы можете починить свое авто:</b>', parse_mode='html', reply_markup=services) # Отправляем сообщение и кнопки
    time.sleep(1) # Задержка на 1 секунду
    fist = telebot.types.ReplyKeyboardMarkup(resize_keyboard=True) # Создаем кнопку оценок
    fist.add(telebot.types.KeyboardButton('👍')) # Создаем кнопку оценки
    fist.add(telebot.types.KeyboardButton('👎')) # Создаем кнопку оценки
    args['problem'] = problem.text
    brandUser = args['brand']  # Зпишем бренд в переную, это нужно что бы вывести его стоке
    fistChoice = bot.send_message(problem.chat.id, f'<b>Оцените статью</b>', parse_mode='html', reply_markup=fist) # Отправляем сообщение и кнопки
    bot.register_next_step_handler(fistChoice, step_grade, args) # как только пользователь выберет кнопку попадаем в step_grade

def step_problem(body, args):
    if body.text == 'Меню': # Если выбрана кнопка меню 
        start = telebot.types.ReplyKeyboardMarkup().add(telebot.types.KeyboardButton('/start')) # Создаем внопку вызывающею комманду /start
        bot.send_message(body.chat.id, '<b>Чтобы продолжить напишите: /start</b>', parse_mode='html', reply_markup=start) # Отправляем сообщение
        return # Завершаем функцию
    if (body.text in car['brands'][args['brand']][args['model']]) is False: # Если ответ от пользователя это не одна из кнопок то выходим 
        return # Завершаем функцию

    problem = telebot.types.ReplyKeyboardMarkup(resize_keyboard=True) # Обьявляем меню проблем 
    for i in car['brands'][ args['brand'] ][ args['model'] ][ body.text ]: # Проходимся по списку кузова
        problem.add(telebot.types.KeyboardButton(i)) # Добавляем проблему в меню
    problem.add(telebot.types.KeyboardButton('Меню')) # Добавляем кнопку выхода в меню 
    problemChoice = bot.send_message(body.chat.id, '<b>Выберите проблему</b>', parse_mode='html', reply_markup=problem) # Отправляем сообщение и меню
    args['body'] = body.text # Зпишем выбраный кузов
    bot.register_next_step_handler(problemChoice, step_result, args) # как только пользователь выберет кнопку попадаем в step_result

def step_body(model, args):
    if model.text == 'Меню': # Если выбрана кнопка меню 
        start = telebot.types.ReplyKeyboardMarkup().add(telebot.types.KeyboardButton('/start')) # Создаем внопку вызывающею комманду /start
        bot.send_message(model.chat.id, '<b>Чтобы продолжить напишите: /start</b>', parse_mode='html', reply_markup=start) # Отправляем сообщение
        return # Завершаем функцию
    if (model.text in car['brands'][args['brand']]) is False: # Если ответ от пользователя это не одна из кнопок то выходим 
        return # Завершаем функцию

    body = telebot.types.ReplyKeyboardMarkup(resize_keyboard=True) # Обьявляем меню кузовов
    for i in car['brands'][args['brand']][model.text]: # Проходимся по кузовам  
        body.add(telebot.types.KeyboardButton(i)) # Добавляем кузов в меню
    body.add(telebot.types.KeyboardButton('Меню')) # Добавляем кнопку выхода в меню 
    bodyChoice = bot.send_message(model.chat.id, '<b>Выберите кузов</b>', parse_mode='html', reply_markup=body) # Отправляем сообщение и меню
    args['model'] = model.text # Запишем модель
    bot.register_next_step_handler(bodyChoice, step_problem, args) # как только пользователь выберет кнопку попадаем в step_problem


def step_model(brand):   
    if (brand.text in car['brands']) is False: # Если ответ от пользователя это не одна из кнопок то выходим 
        return # Завершаем функцию

    models = telebot.types.ReplyKeyboardMarkup(resize_keyboard=True) # Обьявляем меню моделей
    for i in car['brands'][brand.text]: # проходимся по моделям марки
        models.add(telebot.types.KeyboardButton(i)) # Добавляем модель в меню 
    models.add(telebot.types.KeyboardButton('Меню')) # Добавляем выход в меню
    model = bot.send_message(brand.chat.id, '<b>Выберите модель</b>', parse_mode='html', reply_markup=models) # Отправляем сообщение и кнопки
    bot.register_next_step_handler(model, step_body, {'brand': brand.text}) # как только пользователь выберет кнопку попадаем в step_body

@bot.message_handler(content_types=['text']) # Отслеживаем любое текстовое сообщение
def get_user_text(message): # Выполняем на сообщение
    bot.send_message(message.chat.id, f'<b>Привет, {message.from_user.first_name}! Здесь ты можешь найти помощь в починке своего авто.</b>', parse_mode='html') # Отправляем сообщение
    brands = telebot.types.ReplyKeyboardMarkup(resize_keyboard=True) # Обьявляем меню марок, кнопок 
    for i in car['brands']: # Проходимя по марках
        brands.add(telebot.types.KeyboardButton(i)) # Добавляем кнопку в меню
    time.sleep(1) # Задержка 1 секунда
    brand = bot.send_message(message.chat.id, '<b>Выберите марку</b>', parse_mode='html', reply_markup=brands) # Отправляем сообщение и кнопки 
    bot.register_next_step_handler(brand, step_model) # как только пользователь выберет кнопку попадаем в step_model

    
bot.polling(non_stop=True, skip_pending=True) # Запускаем бот